import tkinter as tk
from tkinter import ttk
from tkinter import messagebox      

class Consulta:
    def __init__(self, nomePac, dia, hora, medico):
        self.__nomePac = nomePac
        self.__dia = dia 
        self.__hora = hora
        self.__medico = medico

    @property 
    def nomePac(self):
        return self.__nomePac
    
    @property
    def dia(self):
        return self.__dia
    
    @property
    def hora(self):
        return self.__hora
    
    @property
    def medico(self):
        return self.__medico


class LimiteInsereConsulta(tk.Toplevel):
    def __init__(self, controle, listaEsp):

        tk.Toplevel.__init__(self)
        self.geometry('350x380')
        self.title("Consulta")
        self.controle = controle

        self.frameNomePac = tk.Frame(self)
        self.frameEspec = tk.Frame(self)
        self.frameDia = tk.Frame(self)
        self.frameHora = tk.Frame(self)
        self.frameMedico = tk.Frame(self)
        self.frameButton = tk.Frame(self)
        self.frameNomePac.pack()
        self.frameDia.pack()
        self.frameHora.pack()
        self.frameEspec.pack()
        self.frameMedico.pack()
        self.frameButton.pack()        

        self.labelNomePac = tk.Label(self.frameNomePac,text="Nome do paciente: ")
        self.labelNomePac.pack(side="left")
        self.inputNomePac = tk.Entry(self.frameNomePac, width=15)
        self.inputNomePac.pack(side="left")

        self.labelDia = tk.Label(self.frameDia, text='Informe o dia: ')
        self.labelDia.pack(side="left")
        self.inputDia = tk.Entry(self.frameDia, width=4)
        self.inputDia.pack(side="left")

        self.labelHora = tk.Label(self.frameHora, text='Informe o horário: ')
        self.labelHora.pack(side="left")
        self.inputHora = tk.Entry(self.frameHora, width=4)
        self.inputHora.pack(side="left")

        self.labelEspec = tk.Label(self.frameEspec,text="Escolha a especialidade: ")
        self.labelEspec.pack(side="left")
        self.escolhaCombo = tk.StringVar()
        self.combobox = ttk.Combobox(self.frameEspec, width = 15 , textvariable = self.escolhaCombo)
        self.combobox.pack(side="left")
        self.combobox['values'] = listaEsp
        self.combobox.bind("<<ComboboxSelected>>", self.controle.exibeMedicos)
          
        self.labelMed = tk.Label(self.frameMedico,text="Escolha o médico: ")
        self.labelMed.pack(side="left") 
        self.listbox = tk.Listbox(self.frameMedico)
        self.listbox.pack(side="left")

        self.buttonInsere = tk.Button(self.frameButton ,text="Cadastra Consulta")           
        self.buttonInsere.pack(side="left")
        self.buttonInsere.bind("<Button>", controle.cadastraCons)

        self.buttonLimpa = tk.Button(self.frameButton ,text="Limpa")           
        self.buttonLimpa.pack(side="left")
        self.buttonLimpa.bind("<Button>", controle.clearHandler)

   
    def mostraJanela(self, titulo, msg):
        messagebox.showinfo(titulo, msg)            

class LimiteMostraConsultas():
    def __init__(self, str):
        messagebox.showinfo('Lista de turmas', str)

class CtrlConsulta():       
    def __init__(self, controlePrincipal):
        self.ctrlPrincipal = controlePrincipal
        self.listaConsultas = []

    def getConsultas(self):
        return self.listaConsultas

    def insereConsultas(self):
        self.listaMedicos = self.ctrlPrincipal.ctrlMedico.getMedicos()
        listaEspec = []
        for medico in self.listaMedicos:
            if not medico.especialidade in listaEspec:
                listaEspec.append(medico.especialidade)
        self.limiteIns = LimiteInsereConsulta(self, listaEspec)

    def exibeMedicos(self, event):
        self.limiteIns.listbox.delete(0,tk.END)
        especSel = self.limiteIns.combobox.get()
        for medico in self.listaMedicos:
            if medico.especialidade == especSel:
                self.limiteIns.listbox.insert(tk.END, medico.nome)
        #self.limiteIns.listbox.select_set(tk.FIRST)


    def cadastraCons(self, event):
        try:
            nomePac = self.limiteIns.inputNomePac.get()
            dia = int(self.limiteIns.inputDia.get())
            hora = int(self.limiteIns.inputHora.get())
            nomeMedico = self.limiteIns.listbox.get(tk.ACTIVE)
            self.validaDia(dia)
            self.validaHora(hora)
            medico = self.getMedico(nomeMedico)
            self.horarioDisponivel(medico, dia, hora)
            consulta = Consulta(nomePac, dia, hora, medico)
            self.listaConsultas.append(consulta)
            self.limiteIns.mostraJanela('Sucesso', 'Consulta cadastrado com sucesso')
            self.clearHandler(event)
        except ValueError as error:
            self.limiteIns.mostraJanela('Erro', error) 


    def clearHandler(self, event):
        self.limiteIns.inputNomePac.insert(0, tk.END)
        self.limiteIns.inputDia.delete(0, tk.END)
        self.limiteIns.inputHora.delete(0, tk.END)
        self.limiteIns.listbox.delete(0, tk.END)


    def validaDia(self, dia):
        if dia < 1 or dia > 30:
            raise ValueError("Dia inválido: {}".format(dia))
        
    def validaHora(self, hora):
        if hora < 9 or hora > 17:
            raise ValueError("Hora inválida: {}".format(hora))
        
    def getMedico(self, nome):
        for medico in self.listaMedicos:

            if nome == medico.nome:
                return medico
        raise ValueError("Médico Inválido: {}".format(nome))
    
    def horarioDisponivel(self, medico, dia, hora):
        for consulta in self.listaConsultas:
            if consulta.medico == medico and consulta.dia == dia and consulta.hora == hora:
                raise ValueError("Horário indisponível")