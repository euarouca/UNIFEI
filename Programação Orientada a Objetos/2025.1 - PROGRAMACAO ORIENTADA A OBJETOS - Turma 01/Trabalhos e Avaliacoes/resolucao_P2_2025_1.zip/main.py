import tkinter as tk
from tkinter import messagebox
import consulta as cons
import medico as med

class LimitePrincipal():
    def __init__(self, root, controle):
        self.controle = controle
        self.root = root
        self.root.geometry('300x250')
        self.menubar = tk.Menu(self.root)        
        self.medicoMenu = tk.Menu(self.menubar)
        self.consultaMenu = tk.Menu(self.menubar)     

        self.medicoMenu.add_command(label="Cadastra", \
                    command=self.controle.insereMedicos)
        self.medicoMenu.add_command(label="Exibe Consultas", \
                    command=self.controle.mostraConsultas)
        self.menubar.add_cascade(label="Médico", \
                    menu=self.medicoMenu)

        self.consultaMenu.add_command(label="Cadastra", \
                    command=self.controle.insereConsultas)       
        self.menubar.add_cascade(label="Consulta", \
                    menu=self.consultaMenu)        

        self.root.config(menu=self.menubar)

      
class ControlePrincipal():       
    def __init__(self):
        self.root = tk.Tk()

        self.ctrlMedico = med.CtrlMedico(self)
        self.ctrlConsulta = cons.CtrlConsulta(self)

        self.limite = LimitePrincipal(self.root, self) 

        self.root.title("Marcação de consultas")
        # Inicia o mainloop
        self.root.mainloop()       

    def insereMedicos(self):
        self.ctrlMedico.cadastraMedico()

    def mostraConsultas(self):
        self.ctrlMedico.listaConsultas()        

    def insereConsultas(self):
        self.ctrlConsulta.insereConsultas()

if __name__ == '__main__':
    c = ControlePrincipal()