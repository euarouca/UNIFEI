import tkinter as tk
from tkinter import messagebox, ttk

class Medico:
    def __init__(self, nome, crm, especialidade):
        self.especialidades = ['Pediatria', 'Cardiologia', 'Neurologia', 'Oftalmologia', 'Ortopedia', 'Gastroenterologia', 'Psiquiatria', 'Pneumologia']
        self.__nome = nome
        self.__crm = crm
        self.especialidade = especialidade

    @property
    def nome(self):
        return self.__nome
    
    @property
    def crm(self):
        return self.__crm

    @property
    def especialidade(self):
        return self.__especialidade
    
    @especialidade.setter
    def especialidade(self, especialidade):
        if especialidade not in self.especialidades:
            raise ValueError('Especialidade inválida: {}'.format(especialidade))
        else:
            self.__especialidade = especialidade

class LimiteCadastraMedico(tk.Toplevel):
    def __init__(self, controle):
        tk.Toplevel.__init__(self)
        self.geometry('400x200')
        self.title('Cadastrar Medico')
        self.controle = controle

        self.frameNome = tk.Frame(self)
        self.frameCrm = tk.Frame(self)
        self.frameEspecialidade = tk.Frame(self)
        self.frameButton = tk.Frame(self)

        self.frameNome.pack()
        self.frameCrm.pack()
        self.frameEspecialidade.pack()
        self.frameButton.pack()

        tk.Label(self.frameNome, text='Nome: ').pack(side='left')
        self.inputNome = tk.Entry(self.frameNome, width=20)
        self.inputNome.pack(side='left')

        tk.Label(self.frameCrm, text='CRM: ').pack(side='left')
        self.inputCrm = tk.Entry(self.frameCrm, width=20)
        self.inputCrm.pack(side='left')

        tk.Label(self.frameEspecialidade, text='Especialidade: ').pack(side='left')
        self.inputEspecialidade = tk.Entry(self.frameEspecialidade, width=20)
        self.inputEspecialidade.pack(side='left')

        self.buttonSubmit = tk.Button(self.frameButton, text="Enter")
        self.buttonSubmit.pack(side="left")
        self.buttonSubmit.bind("<Button>", controle.enterCadastraHandler)

        self.buttonClear = tk.Button(self.frameButton, text="Clear")
        self.buttonClear.pack(side="left")
        self.buttonClear.bind("<Button>", controle.clearCadastraHandler)

        self.buttonFecha = tk.Button(self.frameButton, text="Concluído")
        self.buttonFecha.pack(side="left")
        self.buttonFecha.bind("<Button>", controle.fechaCadastraHandler)

    def mostraJanela(self, titulo, msg):
        messagebox.showinfo(titulo, msg)

class LimiteListaConsultas(tk.Toplevel):
    def __init__(self, controle):
        tk.Toplevel.__init__(self)
        self.geometry('400x200')
        self.title('Listar consultas de Medicos')
        self.controle = controle

        self.frameMedico = tk.Frame(self)
        self.frameButton = tk.Frame(self)

        self.frameMedico.pack()
        self.frameButton.pack()

        tk.Label(self.frameMedico, text='Escolha o médico: ').pack(side='left')
        self.comboboxMedicos = ttk.Combobox(self.frameMedico)
        self.comboboxMedicos['values'] = [f'{medico.nome} - {medico.crm}' for medico in controle.listaMedicos]
        self.comboboxMedicos.pack(side='left')
        self.comboboxMedicos.bind("<<ComboboxSelected>>", controle.exibeConsultas)

        self.buttonFecha = tk.Button(self.frameButton, text="Concluído")
        self.buttonFecha.pack(side="left")
        self.buttonFecha.bind("<Button>", controle.fechaListarConsultasHandler)

    def mostraJanela(self, titulo, msg):
        messagebox.showinfo(titulo, msg)

class CtrlMedico:
    def __init__(self, controlePrincipal):
        self.ctrlPrincipal = controlePrincipal
        self.limiteCadastrarMedico = None
        self.limiteListarConsultas = None

        self.listaMedicos = []
        
    def cadastraMedico(self):
        self.limiteCadastrarMedico = LimiteCadastraMedico(self)

    def listaConsultas(self):
        self.limiteListarConsultas = LimiteListaConsultas(self)

    def getMedicos(self):
        return self.listaMedicos

    def buscaMedicoPorCRM(self, crm):
        medicoEncontrado = None
        for medico in self.listaMedicos:
            if medico.crm == crm:
                medicoEncontrado = medico
                break
        return medicoEncontrado

    def enterCadastraHandler(self, event):
        nome = self.limiteCadastrarMedico.inputNome.get()
        crm = self.limiteCadastrarMedico.inputCrm.get()
        especialidade = self.limiteCadastrarMedico.inputEspecialidade.get()

        if not nome or not crm or not especialidade:
            self.limiteCadastrarMedico.mostraJanela('Erro', 'Campos obrigatórios não preenchidos')
            return

        medicoEncontrado = self.buscaMedicoPorCRM(crm)

        if medicoEncontrado != None:
            self.limiteCadastrarMedico.mostraJanela('Erro', 'Medico com esse CRM já cadastrado.\n')
            return

        try:
            medico = Medico(nome, crm, especialidade)
            self.listaMedicos.append(medico)
            self.limiteCadastrarMedico.mostraJanela('Sucesso', 'Médico cadastrado com sucesso.\n')
            self.clearCadastraHandler(event)
        except ValueError as error:
            self.limiteCadastrarMedico.mostraJanela('Erro', error)

    def exibeConsultas(self, e):
        medicoSelecionado = self.limiteListarConsultas.comboboxMedicos.get().split(' - ')

        consultas = ""

        self.listaConsultas = self.ctrlPrincipal.ctrlConsulta.getConsultas()

        for consulta in self.listaConsultas:
            if consulta.medico.crm == medicoSelecionado[1]:
                consultas += f'Dia: {consulta.dia} / Hora: {consulta.hora} / Nome do paciente: {consulta.nomePac}\n'

        if consultas == "":
            self.limiteListarConsultas.mostraJanela('Consultas', 'Nenhuma consulta agendada.\n')
        else:
            self.limiteListarConsultas.mostraJanela('Consultas', consultas)


    def clearCadastraHandler(self, event):
        self.limiteCadastrarMedico.inputNome.delete(0, tk.END)
        self.limiteCadastrarMedico.inputCrm.delete(0, tk.END)
        self.limiteCadastrarMedico.inputEspecialidade.delete(0, tk.END)

    def fechaCadastraHandler(self, event):
        self.limiteCadastrarMedico.destroy()

    def fechaListarConsultasHandler(self, e):
        self.limiteListarConsultas.destroy()